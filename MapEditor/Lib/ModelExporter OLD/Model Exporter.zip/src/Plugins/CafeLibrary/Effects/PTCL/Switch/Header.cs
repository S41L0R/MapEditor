﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CafeLibrary.Effects.Switch.PTCL
{
    public class Header
    {

    }
}
